LIAM SHOPPING CENTER - ANDROID APP PROJECT

App: Liam Shopping Center
Theme: Red / black / white
Offline-first WebView wrapper. The HTML app is stored locally in Android assets.

Build APK using Android Studio:
1. Install Android Studio and Android SDK 35.
2. Open this project folder (LiamAndroid).
3. Allow Gradle sync; if prompted, install Android Gradle Plugin dependencies.
4. In terminal in project root: gradle assembleDebug (requires Gradle installed), or use Android Studio Build > Build APK(s).
5. APK output: app/build/outputs/apk/debug/app-debug.apk

Alternative cloud build:
Upload project to a GitHub repository. The included workflow .github/workflows/build-apk.yml
runs on GitHub Actions (Actions tab > workflow > Run workflow) and publishes APK as artifact.

This archive contains the Android source project, not a precompiled APK. This environment
lacks Android SDK/Gradle build tools, so APK compilation could not be performed here.

Initial POS PIN: 1234. Change the PIN in the app settings. Data is stored in local browser
storage within the app; periodically export JSON backup. No cloud sync is included.
